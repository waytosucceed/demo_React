import './App.css'
import Activity from './Component/Activity'
import Header from './Component/Header'

function App () {
  return (
    <>
      <div>
        <Header />
        <Activity/>
      </div>
    </>
  )
}

export default App
